# SellFlow AI v2 — implementation checklist

- [x] Replace v1 n8n workflow with FAQ learning, script testing, and weekly winner logic.
- [x] Create four-tab Google Sheets workbook template with sample rows.
- [x] Add `/dashboard` route with live webhook configuration and fallback sample metrics.
- [x] Add 20 Harare clothing-store FAQ answers and 5-scenario script variants.
- [x] Update the 15-minute setup guide for v2.
- [x] Run typecheck, production build, JSON validation, and dashboard screenshots.
- [x] Create a v2 checkpoint and package the source deliverables.
