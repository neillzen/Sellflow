# SellFlow AI v2 — Default FAQ Bank + Script Library

Replace all bracketed placeholders before activation. These answers are intentionally short so Tari can keep conversations moving.

## 20 default FAQs for Harare clothing stores

| Question | Default answer |
|---|---|
| What sizes do you have? | We usually carry S to 3XL. Tell me the product and your size and I’ll check it. |
| How much is delivery in Harare? | Delivery is [DELIVERY_FEE] in Harare. Tell me your area and I’ll confirm. |
| Do you deliver outside Harare? | We can confirm delivery outside Harare case by case. Which town should I check? |
| Can I pay with EcoCash? | Yes, payment is through [ECOCASH]. I’ll share the next step when you’re ready. |
| Can I pay cash on delivery? | [CASH_ON_DELIVERY_POLICY]. |
| Can you hold the item? | Yes — tell me your name and size and I’ll request a hold on the [PRODUCT]. |
| How long can you hold it? | Our usual hold window is [HOLD_WINDOW]. |
| Is this still available? | I’ll check the [PRODUCT] in your size. Which size should I confirm? |
| When is new stock coming? | New stock usually lands on [NEW_STOCK_DAYS]. |
| Do you have a physical shop? | Yes, we are at [STORE_ADDRESS]. Our hours are [BUSINESS_HOURS]. |
| Can I visit and try it on? | Yes, fitting-room availability is [FITTING_ROOM_POLICY]. |
| What is the fabric? | The [PRODUCT] is made from [FABRIC]. |
| Is the colour exactly like the photo? | Colours can vary slightly by screen. The available colours are [COLOURS]. |
| Do you do exchanges? | Our exchange policy is [EXCHANGE_POLICY]. |
| Do you accept returns? | Our return policy is [RETURN_POLICY]. |
| Can I order on WhatsApp? | Yes. Send the product, size and your name and we’ll guide you through the order. |
| How fast is delivery? | Delivery usually takes [DELIVERY_TIME] after payment confirmation. |
| Can I collect my order? | Collection is [COLLECTION_POLICY]. |
| Do you offer discounts? | Our current offer is [CURRENT_OFFER]. |
| What if my size is sold out? | I can note your size for the next drop. New stock is usually [NEW_STOCK_DAYS]. |

## Default three variants for five scenarios

| Scenario | Script A | Script B | Script C |
|---|---|---|---|
| follow_up_4hr | Hi, just checking if you still want the [PRODUCT]? | Hey 😊 Still want me to hold the [PRODUCT] in [SIZE] for you? | Quick update: [PRODUCT] in [SIZE] is almost out. Should I reserve it? |
| follow_up_24hr | Still thinking about the [PRODUCT]? I can check your size. | Hi again — should I keep the [PRODUCT] aside for you? | Last check from me: want me to reserve the [PRODUCT] before it goes? |
| price_reply | The [PRODUCT] is [PRICE]. What size should I check? | [PRODUCT] is [PRICE] — should I hold one in your size? | It’s [PRICE] and delivery is [DELIVERY_FEE]. Want to secure yours? |
| size_reply | Yes, we have [SIZE] in the [PRODUCT]. Want it held? | [SIZE] is available — what’s your name so I can note the hold? | I can check [SIZE] now. If it fits, should I reserve it for you? |
| after_delivery_question | We deliver in [AREA] for [DELIVERY_FEE]. Want me to arrange it? | Yes, delivery to [AREA] is [DELIVERY_FEE]. Shall I hold your [PRODUCT]? | I can send the [PRODUCT] to [AREA]. Confirm your size and I’ll share the next step. |

The workbook contains these same rows in `Script_Variants`. Keep `Wins_A`, `Wins_B`, and `Wins_C` numeric, and keep `Winner` as one of A, B or C. The weekly optimizer is designed to compare outcomes rather than assume one script is universally best.
