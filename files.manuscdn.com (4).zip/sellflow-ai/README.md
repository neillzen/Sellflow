# SellFlow AI v2 — Self Learning

Premium landing page, owner dashboard, and self-learning launch kit for an AI WhatsApp sales operator built for Harare clothing stores.

## Run locally

```bash
npm i
npm run dev
```

The managed frontend scaffold uses React 19, Vite, Tailwind CSS 4, shadcn/ui primitives, and Wouter routing. It is static and free-tier friendly; no server or API endpoint is required for the landing page.

## Included launch kit

- `launch-kit/sellflow-ai-v2-workflow.json` — importable 24-node n8n workflow for FAQ learning, A/B/C scripts, weekly winner calculation, follow-ups, and dashboard metrics.
- `sellflow-ai-google-sheet-template.xlsx` — four-tab workbook for FAQ_KnowledgeBase, Learning_Log, Script_Variants, and Sales_Log, with sample rows.
- `launch-kit/env-template.txt` — placeholders for n8n and frontend dashboard configuration.
- `launch-kit/default-faqs-and-scripts.md` — twenty Harare clothing-store FAQs and five script scenarios with A/B/C variants.
- `launch-kit/v2-setup-guide.md` — non-coder setup guide for the self-learning features.
- `launch-kit/sales-and-onboarding.md` — cold DMs, FAQ answers, and owner onboarding form.

The `/dashboard` route reads live JSON from `VITE_DASHBOARD_WEBHOOK_URL` when configured and otherwise shows clearly labelled sample data. Before launch, replace the WhatsApp CTA number, `[STORE_NAME]`, `[PRODUCT_LIST]`, `[ECOCASH_NUMBER]`, and any illustrative copy with your real store details and verified customer proof.
