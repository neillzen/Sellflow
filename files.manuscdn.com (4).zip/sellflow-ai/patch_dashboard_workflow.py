import json
from pathlib import Path
p=Path('/home/ubuntu/sellflow-ai/launch-kit/sellflow-ai-v2-workflow.json')
data=json.loads(p.read_text())
def n(id_,name,typ,pos,params,notes):
    return {'parameters':params,'id':id_,'name':name,'type':typ,'typeVersion':1,'position':pos,'notes':notes}
extra=[
 n('dashsales','U · Dashboard read Sales_Log','n8n-nodes-base.googleSheets',[1320,620],{'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Sales_Log'}},'Reads Sales_Log for purchases and answered conversations.'),
 n('dashlearning','V · Dashboard read Learning_Log','n8n-nodes-base.googleSheets',[1540,620],{'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Learning_Log'}},'Reads pending questions.'),
 n('dashvariants','W · Dashboard read Script_Variants','n8n-nodes-base.googleSheets',[1760,620],{'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Script_Variants'}},'Reads the current Winner.'),
 n('dashcalc','X · Return dashboard JSON','n8n-nodes-base.code',[1980,620],{'mode':'runOnceForAllItems','jsCode':"const sales=$items('U · Dashboard read Sales_Log').map(x=>x.json); const learning=$items('V · Dashboard read Learning_Log').map(x=>x.json); const variants=$input.all().map(x=>x.json); const bought=sales.filter(r=>String(r.Did_Buy||'').toLowerCase()==='yes'); const avg=Number($env.AVG_ORDER_VALUE||50); const winner=variants.find(r=>r.Winner)?.Winner||'A'; const labels={A:'A — Script A',B:'B — Script B',C:'C — Script C'}; return [{json:{moneyRecovered:bought.length*avg,topWinningScript:labels[winner]||winner,newQuestionsToApprove:learning.filter(r=>String(r.Status||'').toLowerCase()==='pending').length,messagesAnswered:sales.length,weekLabel:'This week'}}];"},'Returns the exact JSON shape consumed by /dashboard. Set AVG_ORDER_VALUE in n8n to your average order value.')
]
data['nodes'].extend(extra)
data['connections']['T · Dashboard metrics webhook']={'main':[[{'node':'U · Dashboard read Sales_Log','type':'main','index':0}]]}
data['connections']['U · Dashboard read Sales_Log']={'main':[[{'node':'V · Dashboard read Learning_Log','type':'main','index':0}]]}
data['connections']['V · Dashboard read Learning_Log']={'main':[[{'node':'W · Dashboard read Script_Variants','type':'main','index':0}]]}
data['connections']['W · Dashboard read Script_Variants']={'main':[[{'node':'X · Return dashboard JSON','type':'main','index':0}]]}
p.write_text(json.dumps(data,indent=2))
print('dashboard branch added',len(data['nodes']))
