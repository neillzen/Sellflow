# SellFlow AI v2 — Self Learning Setup Guide

SellFlow AI v2 uses only n8n, Groq, Google Sheets and Evolution API. The included frontend dashboard reads a small JSON response from an n8n GET webhook. No paid database, CRM or AI provider is required.

## Minute 0–3: Prepare the workbook

Open `sellflow-ai-google-sheet-template.xlsx` and upload it to Google Drive. Keep the four tab names exactly as provided: `FAQ_KnowledgeBase`, `Learning_Log`, `Script_Variants`, and `Sales_Log`. Replace sample values such as `[STORE_NAME]`, `[PRODUCTS]`, `[ECOCASH]`, `[DELIVERY_FEE]`, `[AREA]`, and `[NEW_STOCK_DAYS]`.

The FAQ tab stores approved answers. `Times_Asked` is a number and `Last_Used` is a timestamp. The Learning Log stores unknown questions and their AI answers as `Pending`. Review pending rows weekly; the workflow can promote an exact question after three asks, but the owner should still verify the answer before leaving it approved.

## Minute 3–6: Import n8n and connect Google Sheets

Deploy n8n using a free option available to you, then open the n8n editor. Import `launch-kit/sellflow-ai-v2-workflow.json` using **Import from File**. Add Google Sheets OAuth credentials and select the workbook in nodes C, H, I, L, N, O, Q and S.

Set `GOOGLE_SHEET_ID` to the ID between `/d/` and `/edit` in the Google Sheet URL. Set the n8n timezone to the store’s timezone so the Sunday 09:00 optimizer runs when expected.

## Minute 6–8: Connect Groq and Evolution API

Create a free API key in the [Groq Console](https://console.groq.com). Attach it to the HTTP Request node **G · Ask Tari via Groq**, or use the header expression already included in the JSON. Keep the model as `llama-3.1-70b-versatile` unless your available Groq model list requires a current replacement.

Deploy Evolution API, create the store instance, and scan its WhatsApp QR. Point the Evolution webhook at the production URL for **A · Evolution API inbound webhook**. Replace the placeholder system context with your real store name, products, delivery fee and EcoCash number. Never ask Tari to guess stock or payment details.

## Minute 8–11: Turn on FAQ learning

The inbound path normalizes the message, reads `FAQ_KnowledgeBase`, and calculates a simple token-overlap similarity score. A score of 0.80 or higher uses the stored answer and skips Groq. Unknown questions go to Groq, then the question and answer are appended to `Learning_Log` as `Pending`.

The repeat-question branch reads `Learning_Log`. When the same normalized question appears three times, it appends a row to `FAQ_KnowledgeBase` with `Status=Approved`. Keep the approval column in the workbook even if you use the supplied nodes, because it makes manual review visible to the owner.

## Minute 11–13: Turn on script learning

Keep one row for each scenario in `Script_Variants`: `follow_up_4hr`, `follow_up_24hr`, `price_reply`, `size_reply`, and `after_delivery_question`. The A/B/C picker randomly assigns a script to each customer and writes the assignment to `Sales_Log`.

Update `Customer_Replied` to `Yes` when a customer replies within 24 hours. Update `Did_Buy` to `Yes` when the order is paid. The Sunday 09:00 optimizer treats a reply within 24 hours or a purchase as a win, calculates win rate, and writes the highest variant to `Winner`. Use the latest winner row as the next week’s default, or adjust the picker node to read `Winner` before randomizing.

## Minute 13–15: Connect the dashboard

Open the GET webhook **T · Dashboard metrics webhook** and add a small n8n Google Sheets aggregation branch that returns this shape:

```json
{
  "moneyRecovered": 342,
  "topWinningScript": "B — Personal hold",
  "newQuestionsToApprove": 7,
  "messagesAnswered": 486,
  "weekLabel": "This week"
}
```

For `moneyRecovered`, count rows where `Did_Buy=Yes` in the current week and multiply by your configured average order value. For `newQuestionsToApprove`, count `Learning_Log` rows with `Status=Pending`. For `messagesAnswered`, count inbound rows logged to your operational sheet or use the number of sales log rows if that is your chosen message denominator.

Set `VITE_DASHBOARD_WEBHOOK_URL` in the frontend deployment to the n8n GET webhook URL. If it is not set, `/dashboard` intentionally shows clearly labelled sample data rather than pretending it is live.

## Weekly owner routine

Every Sunday, approve or edit pending questions, review the A/B/C winner, update product stock and prices, and test one real-looking message from a consenting test number. The learning system improves from reviewed operational data; it should not be allowed to invent product information.
