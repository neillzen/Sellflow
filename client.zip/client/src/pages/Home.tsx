// Black Label Signal: editorial luxury for Harare retail operators. Use asymmetric composition, ink/ivory surfaces, signal brass accents, and decisive micro-interactions.
import { useState } from "react";
import { ArrowUpRight, BarChart3, Check, ChevronDown, Clock3, MessageCircle, MoveRight, Play, ShieldCheck, Sparkles, Zap } from "lucide-react";

const heroImage = "/manus-storage/sellflow-hero_4348277b.jpg";
const boutiqueImage = "/manus-storage/sellflow-boutique_79ae0cfd.jpg";
const flowImage = "/manus-storage/sellflow-flow_2df5197f.jpg";
const markImage = "/manus-storage/sellflow-mark_6a4074ce.png";

const faqs = [
  ["Can customers pay with EcoCash?", "Yes. Add your store’s EcoCash number during setup and Tari can share it naturally when a customer is ready to pay."],
  ["What about delivery in Harare?", "Set one delivery range for your store — for example $3–$5 in Harare — and Tari will quote it in the conversation."],
  ["How long does setup take?", "Most stores can be ready in one focused session. The included setup guide walks through WhatsApp, Groq, Sheets and deployment."],
  ["Does Tari know my products and sizes?", "You provide the product list, prices, available sizes and stock notes. Tari uses that context to answer clearly without guessing."],
  ["Can I change Tari’s tone?", "Yes. Choose warm, concise, playful or polished language during onboarding. You stay in control of what your customers hear."],
  ["Is there a contract?", "No long-term contract is required. Start with the 14-day trial, then keep the plan that matches your enquiry volume."],
];

function SectionLabel({ children }: { children: React.ReactNode }) { return <div className="section-label"><span className="section-label-line" />{children}</div>; }
function WhatsAppIcon() { return <svg className="whatsapp-icon" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12.04 2.02a9.94 9.94 0 0 0-8.58 15.2L2 22l4.92-1.43a9.94 9.94 0 1 0 5.12-18.55Zm0 18.08a8.1 8.1 0 0 1-4.13-1.13l-.3-.18-2.92.85.87-2.84-.2-.31a8.1 8.1 0 1 1 6.68 3.61Zm4.44-6.07c-.24-.12-1.42-.7-1.64-.78-.22-.08-.38-.12-.55.12-.16.24-.63.78-.77.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.92-1.18-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.02-.37.1-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.55-1.32-.75-1.81-.2-.47-.4-.41-.55-.42h-.47c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.68 2.57 4.08 3.6.57.25 1.02.4 1.37.51.58.18 1.11.16 1.52.1.46-.07 1.42-.58 1.62-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28Z" /></svg>; }
function WhatsAppBubble({ children, dark = false }: { children: React.ReactNode; dark?: boolean }) { return <div className={dark ? "wa-bubble wa-bubble-dark" : "wa-bubble"}>{children}<span className="wa-time">10:42</span></div>; }

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  return (
    <div className="site-shell">
      <header className="nav-wrap">
        <a href="#top" className="brand-lockup" aria-label="SellFlow AI home"><img src={markImage} alt="" /><span>SELLFLOW <em>AI</em></span></a>
        <nav className="desktop-nav"><a href="#how-it-works">How it works</a><a href="#features">Features</a><a href="#pricing">Pricing</a><a href="#faq">FAQ</a><a href="/dashboard">Owner view</a></nav>
        <a className="nav-cta" href="https://wa.me/263770000000?text=Hi%20SellFlow%20AI%2C%20I%27d%20like%20to%20start%20my%2014-day%20trial.">Start free <ArrowUpRight size={15} /></a>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-copy">
            <SectionLabel>THE AI SALES OPERATOR / HARARE</SectionLabel>
            <h1>Turn WhatsApp enquiries into <i>sales</i> while you sleep.</h1>
            <p className="hero-sub">A warm, always-on AI salesperson for Harare clothing stores. Answers customers, follows up automatically, and keeps every opportunity moving.</p>
            <div className="hero-actions"><a className="button-whatsapp" href="https://wa.me/263714672039?text=Hi%20I%20want%20SellFlow%20AI%20for%20my%20store"><WhatsAppIcon /> Chat With Me On WhatsApp <ArrowUpRight size={17} /></a><a className="text-link" href="#how-it-works"><span className="play-icon"><Play size={12} fill="currentColor" /></span> See how it works</a></div>
            <div className="hero-proof"><span><ShieldCheck size={15} /> No card required</span><span><Clock3 size={15} /> Setup in one session</span><span><Zap size={15} /> Built for local retail</span></div>
          </div>
          <div className="hero-visual">
            <img src={heroImage} alt="Boutique owner reviewing customer enquiries on WhatsApp" /><div className="signal-line hero-signal"><span>ENQUIRY</span><i /><span>REPLY</span><i /><span>SALE</span></div>
            <div className="hero-caption">THE MOMENT BETWEEN<br /><strong>“HOW MUCH?”</strong> AND “I’LL TAKE IT.”</div>
            <div className="hero-stat"><span>ENQUIRIES ANSWERED</span><strong>24/7</strong><small>while your store is closed</small></div>
          </div>
        </section>

        <section className="signal-strip"><div>BUILT FOR THE WAY HARARE SHOPS SELL</div><div className="signal-dots">● ● ●</div><div>WHATSAPP · ECOCASH · LOCAL DELIVERY</div></section>

        <section className="problem-section section-pad">
          <div className="section-intro"><SectionLabel>THE LEAK IN YOUR SALES</SectionLabel><h2>Good products. <span>Missed moments.</span></h2><p>When a customer asks about size, price or delivery and hears nothing back, the sale doesn’t wait. SellFlow makes sure your best leads never sit unanswered.</p></div>
          <div className="stats-rail"><div className="stat-card"><strong>01</strong><b>Slow replies<br />lose momentum.</b><p>The customer who is ready now may be gone by tonight.</p></div><div className="stat-card stat-card-brass"><strong>02</strong><b>Follow-ups<br />are forgotten.</b><p>Busy store days mean warm leads quietly cool down.</p></div><div className="stat-card"><strong>03</strong><b>Every enquiry<br />is a signal.</b><p>Tari turns conversations into a clear next step.</p></div></div>
        </section>

        <section id="features" className="features-section section-pad dark-section">
          <div className="features-heading"><SectionLabel>ONE OPERATOR. THREE MOVES.</SectionLabel><h2>Less chasing.<br /><em>More closing.</em></h2><p>Tari handles the repetitive parts of selling, so you can stay focused on stock, styling and the customers who are ready to buy.</p></div>
          <div className="feature-list"><div className="flow-index"><span>CHAT</span><i /><span>FOLLOW-UP</span><i /><span>ORDER</span></div><div className="feature-item"><div className="feature-icon"><MessageCircle /></div><div><span>01 — IN THE MOMENT</span><h3>Instant replies</h3><p>Answer “price?”, “size 12?” and “do you deliver?” in a short, human voice — even after hours.</p></div><ArrowUpRight className="feature-arrow" /></div><div className="feature-item"><div className="feature-icon"><Clock3 /></div><div><span>02 — WHEN IT COUNTS</span><h3>Auto follow-ups</h3><p>Give warm leads a gentle nudge after 4 hours, then a timely stock reminder the next day.</p></div><ArrowUpRight className="feature-arrow" /></div><div className="feature-item"><div className="feature-icon"><BarChart3 /></div><div><span>03 — SEE THE PATTERN</span><h3>Revenue reports</h3><p>Know which products, sizes and conversations are creating the most buying intent.</p></div><ArrowUpRight className="feature-arrow" /></div></div>
        </section>

        <section id="how-it-works" className="workflow-section section-pad">
          <div className="workflow-media"><img src={flowImage} alt="Abstract visual showing enquiries flowing into orders" /><div className="workflow-tag">FROM CHAT<br />TO CHECKOUT</div></div>
          <div className="workflow-content"><SectionLabel>THE SETUP IS SIMPLE</SectionLabel><h2>Three steps between <i>hello</i> and paid.</h2><div className="steps"><div><b>01</b><div><h3>Connect your WhatsApp</h3><p>Scan a QR code to connect your store line. No developer required.</p></div></div><div><b>02</b><div><h3>Give Tari your context</h3><p>Add products, prices, sizes, delivery fees and your preferred tone.</p></div></div><div><b>03</b><div><h3>Let the flow run</h3><p>Customers get answers. Leads land in your sheet. You step in when it’s time to close.</p></div></div><div><b>04</b><div><h3>Local answers, built in</h3><p>Works with EcoCash. Knows Harare delivery fees $3-$5.</p></div></div></div><a className="text-link dark-link" href="#pricing">View plans <MoveRight size={18} /></a></div>
        </section>

        <section className="console-section section-pad dark-section"><div className="console-intro"><SectionLabel>WHAT TARI SOUNDS LIKE</SectionLabel><h2>Human enough<br />to <em>sell.</em></h2><p>Warm, short, and local. No robotic paragraphs. No made-up stock. Just the next useful answer.</p></div><div className="phone-frame"><div className="phone-top"><span>‹</span><div className="phone-avatar">T</div><div><b>Tari · SellFlow AI</b><small>online now</small></div><span className="phone-more">•••</span></div><div className="chat-date">TODAY</div><WhatsAppBubble dark>Hi! Yes, the linen co-ord is available in black and cream. It’s <strong>$38</strong>.</WhatsAppBubble><WhatsAppBubble dark>We deliver around Harare for $3–$5. What size should I check for you?</WhatsAppBubble><div className="typing"><span /> <span /> <span /></div><div className="phone-input">Message <b>➤</b></div></div></section>

        <section id="pricing" className="pricing-section section-pad"><div className="pricing-top"><div><SectionLabel>START SMALL. GROW SMART.</SectionLabel><h2>A plan for your<br /><i>next sale.</i></h2></div><p>Every plan includes the AI salesperson, your custom store context, automated follow-ups and a Google Sheet lead log.</p></div><div className="pricing-grid"><div className="pricing-signal"><span>ENQUIRY</span><i /><span>REPLY</span><i /><span>REVENUE</span></div><PriceCard name="Starter" price="19" desc="For focused boutiques building their reply habit." items={["1 WhatsApp number","Up to 300 enquiries / month","Instant replies + lead log"]} /><PriceCard name="Growth" price="49" desc="For busy stores ready to turn momentum into revenue." featured items={["1 WhatsApp number","Up to 1,000 enquiries / month","Instant replies + follow-ups","Revenue reports"]} /><PriceCard name="Pro" price="99" desc="For multi-line stores with a bigger sales floor." items={["Up to 3 WhatsApp numbers","Up to 3,000 enquiries / month","Priority setup support"]} /></div></section>

        <section className="owner-section section-pad"><div className="owner-image"><img src={boutiqueImage} alt="Garments arranged in a premium boutique" /><span>SELL MORE<br />OF WHAT<br /><i>ALREADY<br />WORKS.</i></span></div><div className="owner-copy"><SectionLabel>MADE FOR THE STORE OWNER</SectionLabel><blockquote>“SellFlow replied to 200+ customers for me. I made $800 extra last month”</blockquote><p className="testimonial-attribution">— Tari, Joina City Boutique, Harare</p><a className="text-link dark-link" href="https://wa.me/263770000000?text=Hi%20SellFlow%20AI%2C%20I%27d%20like%20to%20see%20how%20it%20works.">Talk to SellFlow <MoveRight size={18} /></a></div></section>

        <section id="faq" className="faq-section section-pad"><div className="faq-heading"><SectionLabel>NO MYSTERY, JUST MOMENTUM.</SectionLabel><h2>Questions, <i>answered.</i></h2></div><div className="faq-list">{faqs.map(([q, a], i) => <div className={`faq-row ${openFaq === i ? "is-open" : ""}`} key={q}><button onClick={() => setOpenFaq(openFaq === i ? null : i)} aria-expanded={openFaq === i}><span>0{i + 1}</span><b>{q}</b><ChevronDown size={20} /></button>{openFaq === i && <p>{a}</p>}</div>)}</div></section>

        <section className="final-cta"><div className="cta-mark"><img src={markImage} alt="" /></div><div><SectionLabel>YOUR NEXT SALE IS ALREADY IN THE CHAT</SectionLabel><h2>Don’t let “Hi, is this available?”<br /><i>go cold.</i></h2></div><a className="button-brass" href="https://wa.me/263770000000?text=Hi%20SellFlow%20AI%2C%20I%27d%20like%20to%20start%20my%2014-day%20trial.">Start your free trial <ArrowUpRight size={18} /></a></section>
      </main>

      <footer><div className="footer-brand"><a className="brand-lockup" href="#top"><img src={markImage} alt="" /><span>SELLFLOW <em>AI</em></span></a><p>The always-on WhatsApp sales operator for Harare clothing stores.</p></div><div className="footer-links"><div><span>EXPLORE</span><a href="#features">Features</a><a href="#how-it-works">How it works</a><a href="#pricing">Pricing</a></div><div><span>LET’S TALK</span><a href="https://wa.me/263714672039">WhatsApp us ↗</a><span className="footer-number">0714672039</span><a href="mailto:hello@sellflow.ai">hello@sellflow.ai</a></div></div><div className="footer-bottom"><span>© 2026 SELLFLOW AI</span><span>HARARE, ZIMBABWE</span><span>BUILT FOR THE NEXT SALE.</span></div></footer>
    </div>
  );
}

function PriceCard({ name, price, desc, items, featured = false }: { name: string; price: string; desc: string; items: string[]; featured?: boolean }) { return <div className={`price-card ${featured ? "featured" : ""}`}>{featured && <span className="best-value">BEST VALUE</span>}<span className="plan-name">{name}</span><div className="price"><sup>$</sup>{price}<small>/mo</small></div><p>{desc}</p><div className="price-rule" />{items.map(x => <div className="price-item" key={x}><Check size={16} />{x}</div>)}<a href="https://wa.me/263770000000?text=Hi%20SellFlow%20AI%2C%20I%27d%20like%20to%20start%20the%20{encodeURIComponent(name)}%20plan." className={featured ? "button-dark" : "button-outline"}>Choose {name} <ArrowUpRight size={16} /></a></div> }
