# SellFlow AI v1 — 15-Minute Setup Guide

This guide connects the included landing page, n8n workflow, Groq, Evolution API, WhatsApp and Google Sheets. The free tiers change over time, so check each provider’s current limits before launching to customers.

## 1. Create your n8n workspace

Open [Railway](https://railway.app), create an account, and start a new project. Choose a public n8n template if available, or deploy n8n using the official [n8n hosting documentation](https://docs.n8n.io/hosting/). Add the values from `env-template.txt` to your Railway service variables. Use a strong `N8N_ENCRYPTION_KEY`; do not share it.

After deployment, open the n8n URL and create your owner account. In the top-right menu, choose **Import from File** and upload `sellflow-ai-workflow.json`.

## 2. Get a Groq API key

Open the [Groq Console](https://console.groq.com), create an account, and create an API key. In n8n, create a credential for an HTTP Header Auth request with header name `Authorization` and value `Bearer YOUR_GROQ_API_KEY`. Attach it to the node named **C · Tari via Groq**. Keep the key private.

Open that node and replace `[STORE_NAME]`, `[PRODUCT_LIST]` and `[ECOCASH_NUMBER]` inside the system prompt. Use real products and prices only. Tari should never invent stock, delivery areas or payment details.

## 3. Deploy Evolution API and connect WhatsApp

Use the [Evolution API documentation](https://doc.evolution-api.com/) to deploy an Evolution API instance on Railway or another free service that supports your region. Set its API key and public URL in your n8n environment values. Create an instance named `store-whatsapp` or replace the value of `EVOLUTION_INSTANCE`.

In Evolution API, create or connect the instance and open the QR endpoint shown in its dashboard. On the store owner’s phone, open WhatsApp → Linked devices → Link a device and scan the QR. Use a dedicated store number where possible. Do not use a personal number without understanding WhatsApp’s account and device policies.

In Evolution API, configure the message webhook URL to the n8n webhook URL shown by the **A · Evolution API Webhook** node. Send a test message containing “price” to confirm that n8n receives the event.

## 4. Connect Google Sheets

Create a new Google Sheet named `SellFlow Leads` with a tab named `Leads`. Add these headers in row one: `Timestamp`, `CustomerPhone`, `CustomerMessage`, `ProductMentioned`, `Status`, and optionally `CustomerName` and `Size`.

Open the **D · Log new lead** node, create a Google Sheets OAuth credential, select the spreadsheet, and choose the `Leads` sheet. Copy the spreadsheet ID from its URL into `GOOGLE_SHEET_ID`. Turn the workflow on only after a test row appears correctly.

## 5. Test the full flow

Send a message such as “How much is the black dress, and do you deliver?” from a test number. Confirm that the AI reply is short and accurate, that the lead is appended to Sheets, and that the 4-hour wait is visible in the execution. For testing, you may temporarily change the wait values to 1 minute and then restore them to 4 hours and 20 hours.

Update the Sheet status from `New Lead` to `Contacted` before a follow-up is due to confirm that the IF node prevents unnecessary messages. Test a real follow-up only with a consenting test contact.

## 6. Deploy the landing page

The included site is already structured for a managed static deployment. For a local run, open a terminal in the project folder and run:

```bash
npm i
npm run dev
```

To publish through Vercel, import the project from GitHub in [Vercel](https://vercel.com), use the default build settings, and deploy. The site uses no paid API at runtime. Replace the placeholder WhatsApp number in the CTA links with your real business contact number.

## Launch checklist

Before sharing the link, replace `[STORE_NAME]`, `[PRODUCT_LIST]`, `[ECOCASH_NUMBER]`, the WhatsApp CTA number, and the illustrative copy note. Confirm delivery fees, return rules, stock language, and business hours. Test the first reply, a non-sales message, a product question, a payment question, and a stop/follow-up scenario. Keep an owner available to take over conversations that need judgment.
