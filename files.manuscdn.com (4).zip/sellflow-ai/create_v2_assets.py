import json
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

root = Path('/home/ubuntu/sellflow-ai')
kit = root / 'launch-kit'
kit.mkdir(exist_ok=True)

def node(id_, name, typ, pos, parameters, notes=''):
    item = {'parameters': parameters, 'id': id_, 'name': name, 'type': typ, 'typeVersion': 1, 'position': pos}
    if notes: item['notes'] = notes
    return item

nodes = [
node('inbound','A · Evolution API inbound webhook','n8n-nodes-base.webhook',[-1500,0],{'httpMethod':'POST','path':'sellflow-v2-inbox','responseMode':'onReceived'},'Receives inbound WhatsApp events from Evolution API.'),
node('normalize','B · Normalize message','n8n-nodes-base.code',[-1280,0],{'jsCode':"const body=$json.body||$json; const text=body.data?.message?.conversation||body.data?.message?.extendedTextMessage?.text||''; return [{json:{question:String(text).trim(),phone:body.data?.key?.remoteJid||'',receivedAt:new Date().toISOString()}}];"},'Extracts the customer question and phone number into stable fields.'),
node('faqread','C · Read FAQ knowledge base','n8n-nodes-base.googleSheets',[-1060,0],{'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'FAQ_KnowledgeBase'}},'Reads Question, Answer, Times_Asked, Last_Used rows.'),
node('fuzz','D · Fuzzy FAQ match > 80%','n8n-nodes-base.code',[-820,0],{'mode':'runOnceForAllItems','jsCode':"const input=$items('B · Normalize message')[0].json; const rows=$input.all().map(x=>x.json); const clean=s=>String(s||'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').split(/\\s+/).filter(Boolean); const a=clean(input.question); const score=(b)=>{const set=new Set(b); const overlap=a.filter(x=>set.has(x)).length; return a.length?overlap/a.length:0}; let best={score:0,answer:''}; for(const r of rows){const s=score(clean(r.Question)); if(s>best.score) best={score:s,answer:r.Answer||'',row:r};} return [{json:{...input,faqScore:best.score,faqAnswer:best.answer,faqRow:best.row||{}}}];"},'Uses a transparent token-overlap fuzzy match. Replace with a stronger code implementation later if needed; 0.8 is the approval threshold.'),
node('faqif','E · FAQ match above 80%?','n8n-nodes-base.if',[-580,0],{'conditions':{'number':[{'value1':'={{ $json.faqScore }}','operation':'largerEqual','value2':0.8}]}},'Known answers skip the AI call.'),
node('known','F · Use approved answer','n8n-nodes-base.code',[-320,-180],{'jsCode':"return [{json:{...$json,aiAnswer:$json.faqAnswer,answerSource:'FAQ_KnowledgeBase'}}];"},'Uses the approved answer from the sheet.'),
node('groq','G · Ask Tari via Groq','n8n-nodes-base.httpRequest',[-320,180],{'method':'POST','url':'={{ $env.GROQ_API_URL || \'https://api.groq.com/openai/v1/chat/completions\' }}','sendHeaders':True,'headerParameters':{'parameters':[{'name':'Authorization','value':'=Bearer {{$env.GROQ_API_KEY}}'},{'name':'Content-Type','value':'application/json'}]},'sendBody':True,'specifyBody':'json','jsonBody':"={{ JSON.stringify({model:$env.GROQ_MODEL||'llama-3.1-70b-versatile',temperature:0.35,messages:[{role:'system',content:'You are Tari, a friendly sales assistant for [STORE_NAME]. Answer briefly in a warm Zimbabwean tone. Use only this context: [PRODUCTS]. Delivery: [DELIVERY_FEE]. Payment: [ECOCASH]. Ask for name, size, and whether the customer wants the item held. If unsure, say you will confirm with the store.'},{role:'user',content:$json.question}]}) }}"},'Answers unknown questions with Groq.'),
node('pending','H · Save new Q+A as Pending','n8n-nodes-base.googleSheets',[-40,180],{'operation':'append','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Learning_Log'},'columns':{'mappingMode':'defineBelow','value':{'Question':'={{ $json.question }}','AI_Answer':'={{ $json.choices?.[0]?.message?.content || $json.aiAnswer || \'\' }}','Date':'={{ new Date().toISOString() }}','Status':'Pending'}}},'Stores unknown answers for owner review.'),
node('count','I · Count repeat question','n8n-nodes-base.googleSheets',[-40,380],{'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Learning_Log'}},'Reads the learning log so repeated unknown questions can be promoted.'),
node('promote','J · Promote after 3 asks','n8n-nodes-base.code',[200,380],{'mode':'runOnceForAllItems','jsCode':"const q=$items('B · Normalize message')[0].json.question; const rows=$input.all().map(x=>x.json); const count=rows.filter(r=>String(r.Question||'').toLowerCase().trim()===q.toLowerCase().trim()).length; return [{json:{...$items('B · Normalize message')[0].json,repeatCount:count,shouldPromote:count>=3}}];"},'Exact-repeat guard: three asks creates an approval candidate. Owner should verify before treating it as trusted knowledge.'),
node('promoteif','K · Three repeats?','n8n-nodes-base.if',[420,380],{'conditions':{'boolean':[{'value1':'={{ $json.shouldPromote }}','operation':'isTrue'}]}},'Routes repeated questions to the knowledge base.'),
node('kbappend','L · Add approved FAQ','n8n-nodes-base.googleSheets',[660,380],{'operation':'append','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'FAQ_KnowledgeBase'},'columns':{'mappingMode':'defineBelow','value':{'Question':'={{ $json.question }}','Answer':'={{ $items(\'G · Ask Tari via Groq\')[0].json.choices?.[0]?.message?.content || \'\' }}','Times_Asked':'3','Last_Used':'={{ new Date().toISOString() }}','Status':'Approved'}}},'Adds a verified-after-repeat FAQ row.'),
node('scriptpick','M · Pick A/B/C script','n8n-nodes-base.code',[0,-240],{'jsCode':"const variants=['A','B','C']; const pick=variants[Math.floor(Math.random()*variants.length)]; return [{json:{...$json,scriptUsed:pick,scenario:$json.scenario||'price_reply'}}];"},'Randomly assigns a script variant for the scenario.'),
node('scriptread','N · Read Script_Variants','n8n-nodes-base.googleSheets',[-220,-420],{'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Script_Variants'}},'Reads the current winner and script text.'),
node('saleslog','O · Log Script_Used','n8n-nodes-base.googleSheets',[260,-240],{'operation':'append','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Sales_Log'},'columns':{'mappingMode':'defineBelow','value':{'Phone':'={{ $json.phone }}','Scenario':'={{ $json.scenario }}','Script_Used':'={{ $json.scriptUsed }}','Customer_Replied':'No','Did_Buy':'No','Date':'={{ new Date().toISOString() }}'}}},'Logs the experiment assignment.'),
node('weekly','P · Sunday 09:00 optimizer','n8n-nodes-base.scheduleTrigger',[0,620],{'rule':{'interval':[{'field':'weeks','triggerAtDay':0,'triggerAtHour':9,'triggerAtMinute':0}]}},'Runs every Sunday at 09:00 in the n8n timezone.'),
node('salesread','Q · Read Sales_Log + variants',[260,620], 'n8n-nodes-base.googleSheets', {'operation':'read','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Sales_Log'}},'Reads replies and purchases for win-rate calculation.'),
node('calc','R · Calculate weekly winners',[520,620],'n8n-nodes-base.code',{'mode':'runOnceForAllItems','jsCode':"const rows=$input.all().map(x=>x.json); const out=['A','B','C'].map(v=>{const assigned=rows.filter(r=>r.Script_Used===v); const wins=assigned.filter(r=>String(r.Customer_Replied).toLowerCase()==='yes'||String(r.Did_Buy).toLowerCase()==='yes').length; return {variant:v,assigned:assigned.length,wins,rate:assigned.length?wins/assigned.length:0};}); out.sort((a,b)=>b.rate-a.rate); return [{json:{winner:out[0]?.variant||'A',results:out,calculatedAt:new Date().toISOString()}}];"},'Win = customer replied within 24h or Did_Buy is Yes. Winner is the highest win rate.'),
node('update','S · Write Winner to Script_Variants',[800,620],'n8n-nodes-base.googleSheets',{'operation':'append','documentId':{'__rl':True,'mode':'id','value':'={{ $env.GOOGLE_SHEET_ID }}'},'sheetName':{'__rl':True,'mode':'name','value':'Script_Variants'},'columns':{'mappingMode':'defineBelow','value':{'Winner':'={{ $json.winner }}','Last_Calculated':'={{ $json.calculatedAt }}','Win_Rate_A':'={{ $json.results[0]?.rate || 0 }}','Win_Rate_B':'={{ $json.results[1]?.rate || 0 }}','Win_Rate_C':'={{ $json.results[2]?.rate || 0 }}'}}},'Persists the weekly winner and rates; keep the latest row as the active record.'),
node('dashboard','T · Dashboard metrics webhook','n8n-nodes-base.webhook',[1080,620],{'httpMethod':'GET','path':'sellflow-dashboard','responseMode':'lastNode'},'Optional GET endpoint consumed by /dashboard. Return moneyRecovered, topWinningScript, newQuestionsToApprove and messagesAnswered as JSON.')
]
connections={
'A · Evolution API inbound webhook':{'main':[[{'node':'B · Normalize message','type':'main','index':0}]]},
'B · Normalize message':{'main':[[{'node':'C · Read FAQ knowledge base','type':'main','index':0}]]},
'C · Read FAQ knowledge base':{'main':[[{'node':'D · Fuzzy FAQ match > 80%','type':'main','index':0}]]},
'D · Fuzzy FAQ match > 80%':{'main':[[{'node':'E · FAQ match above 80%?','type':'main','index':0}]]},
'E · FAQ match above 80%?':{'main':[[{'node':'F · Use approved answer','type':'main','index':0}],[{'node':'G · Ask Tari via Groq','type':'main','index':0}]]},
'G · Ask Tari via Groq':{'main':[[{'node':'H · Save new Q+A as Pending','type':'main','index':0},{'node':'I · Count repeat question','type':'main','index':0}]]},
'I · Count repeat question':{'main':[[{'node':'J · Promote after 3 asks','type':'main','index':0}]]},
'J · Promote after 3 asks':{'main':[[{'node':'K · Three repeats?','type':'main','index':0}]]},
'K · Three repeats?':{'main':[[{'node':'L · Add approved FAQ','type':'main','index':0}],[]]},
'P · Sunday 09:00 optimizer':{'main':[[{'node':'Q · Read Sales_Log + variants','type':'main','index':0}]]},
'Q · Read Sales_Log + variants':{'main':[[{'node':'R · Calculate weekly winners','type':'main','index':0}]]},
'R · Calculate weekly winners':{'main':[[{'node':'S · Write Winner to Script_Variants','type':'main','index':0}]]}
}
workflow={'name':'SellFlow AI v2 — Self Learning Sales Agent','nodes':nodes,'connections':connections,'active':False,'settings':{'executionOrder':'v1'},'versionId':'sellflow-ai-v2'}
(kit/'sellflow-ai-v2-workflow.json').write_text(json.dumps(workflow,indent=2),encoding='utf-8')

wb=Workbook(); ws=wb.active; ws.title='FAQ_KnowledgeBase'
faq=[('Question','Answer','Times_Asked','Last_Used','Status'),('What sizes do you have?','We currently have sizes S to 3XL. Tell me your size and I will check the item for you.',0,'','Approved'),('How much is delivery in Harare?','Delivery in Harare is [DELIVERY_FEE]. I can confirm the exact fee for your area.',0,'','Approved'),('Can I pay with EcoCash?','Yes — you can pay with EcoCash on [ECOCASH].',0,'','Approved'),('Can you hold it for me?','Yes, tell me your name and size and I can request that the [PRODUCT] be held for you.',0,'','Approved'),('When is new stock coming?','New stock usually lands on [NEW_STOCK_DAYS]. Follow the page for the latest drop.',0,'','Approved')]
for row in faq: ws.append(row)
ws2=wb.create_sheet('Learning_Log'); ws2.append(['Question','AI_Answer','Date','Status']); ws2.append(['Do you have a fitting room?','Yes, please confirm with the store for today’s fitting-room availability.','2026-08-24','Pending'])
ws3=wb.create_sheet('Script_Variants'); ws3.append(['Scenario','Script_A','Script_B','Script_C','Wins_A','Wins_B','Wins_C','Winner','Last_Calculated']); variants={
'follow_up_4hr':('Hi, just checking if you still want the [PRODUCT]?','Hey 😊 Still want me to hold the [PRODUCT] in [SIZE] for you?','Quick update: [PRODUCT] in [SIZE] is almost out. Should I reserve it?'),
'follow_up_24hr':('Still thinking about the [PRODUCT]? I can check your size.','Hi again — should I keep the [PRODUCT] aside for you?','Last check from me: want me to reserve the [PRODUCT] before it goes?'),
'price_reply':('The [PRODUCT] is [PRICE]. What size should I check?','[PRODUCT] is [PRICE] — should I hold one in your size?','It’s [PRICE] and delivery is [DELIVERY_FEE]. Want to secure yours?'),
'size_reply':('Yes, we have [SIZE] in the [PRODUCT]. Want it held?','[SIZE] is available — what’s your name so I can note the hold?','I can check [SIZE] now. If it fits, should I reserve it for you?'),
'after_delivery_question':('We deliver in [AREA] for [DELIVERY_FEE]. Want me to arrange it?','Yes, delivery to [AREA] is [DELIVERY_FEE]. Shall I hold your [PRODUCT]?','I can send the [PRODUCT] to [AREA]. Confirm your size and I’ll share the next step.')}
for s,v in variants.items(): ws3.append([s,*v,0,0,0,'A',''])
ws4=wb.create_sheet('Sales_Log'); ws4.append(['Phone','Scenario','Script_Used','Customer_Replied','Did_Buy','Date']); ws4.append(['26377XXXXXXX','price_reply','B','Yes','No','2026-08-24'])
for sheet in wb.worksheets:
    sheet.freeze_panes='A2'; sheet.auto_filter.ref=sheet.dimensions
    for cell in sheet[1]: cell.font=Font(bold=True,color='FFFFFF'); cell.fill=PatternFill('solid',fgColor='10100F'); cell.alignment=Alignment(wrap_text=True)
    for col in sheet.columns:
        letter=col[0].column_letter; sheet.column_dimensions[letter].width=min(max(max(len(str(c.value or '')) for c in col)+2,12),48)
wb.save(root/'sellflow-ai-google-sheet-template.xlsx')
print('created workflow and workbook')
