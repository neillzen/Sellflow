# SellFlow AI Design Direction

## Three possible approaches

### Theme Name: Midnight Commerce
Very Brief Intro: A dark, high-contrast SaaS world with electric accents and an always-on sales-assistant feeling.
Probability: 0.07

### Theme Name: Sunlit Studio
Very Brief Intro: A warm, editorial retail aesthetic with creamy neutrals, tactile paper texture, and fashion-magazine restraint.
Probability: 0.06

### Theme Name: Black Label Signal
Very Brief Intro: A premium black, ivory, and brass identity that treats WhatsApp selling like a sharp retail operating system for ambitious Harare stores.
Probability: 0.04

## Chosen approach: Black Label Signal

### Design Movement
Contemporary editorial luxury with Swiss-inspired information hierarchy and tactile retail packaging cues.

### Core Principles
1. Make the value proposition feel immediate, physical, and sale-oriented rather than abstractly “AI.”
2. Use asymmetric compositions and strong left alignment to create confidence and pace.
3. Pair quiet premium surfaces with one ownable brass-gold signal color.
4. Treat every interaction as a small conversion moment: clear action, clear response, no friction.

### Color Philosophy
Black and warm ivory create the feeling of a high-trust operator’s tool; brass is used sparingly as a “signal” color for revenue, action, and proof. The palette should feel like a premium garment label, not a generic software template.

### Layout Paradigm
An editorial rail system: narrow utility labels, oversized headlines, staggered content blocks, and diagonal or offset cards that suggest a live flow of conversations moving toward purchase.

### Signature Elements
- Brass “signal line” accents that connect conversation bubbles to revenue outcomes.
- Dark ink panels with thin ivory rules, like a luxury lookbook or product spec sheet.
- Circular monogram mark built from two interlocking flow arrows, used as both logo and favicon.

### Interaction Philosophy
Interactions should feel decisive and tactile. Buttons compress slightly on press, cards lift on hover, FAQ answers unfold cleanly, and every CTA points toward a real contact path or visible next step.

### Animation
Use short, confident reveals under 300ms. Stagger hero proof chips and conversation messages by 50ms. Animate only opacity and transform; use a snappy ease-out. Respect reduced motion preferences.

### Typography System
Display: DM Serif Display for editorial authority and warmth. Body/UI: Plus Jakarta Sans for clarity and modern commerce energy. Headlines use tight tracking and generous line-height; labels use uppercase, small size, and letter spacing.

### Brand Essence
SellFlow AI is the always-on WhatsApp sales operator for Harare clothing stores that want more replies to become paid orders without hiring another person.
Personality: sharp, warm, capable.

### Brand Voice
Headlines are direct and commercially literate. CTAs are active and specific. Microcopy sounds like a trusted operator who knows local retail realities.
Example lines:
- “Every enquiry is a fitting-room door. Keep it open.”
- “Let Tari handle the first reply. You handle the best customers.”

### Wordmark & Logo
A compact interlocking “S/F” flow mark: two brass strokes create a forward-moving loop, paired with a custom-feeling wordmark lockup in uppercase small caps. The mark should be recognizable without the name.

### Signature Brand Color
Signal Brass — #C9A46C. Use it for primary CTAs, key metrics, active states, and the flow-line motif.

## Style Decisions
- Use the Black Label Signal system consistently across the hero, feature cards, mock WhatsApp console, pricing, FAQ, and footer.
- Avoid generic SaaS gradients, excessive rounded cards, and centered-only compositions.
- Keep testimonial copy clearly framed as illustrative/sample copy rather than fabricated customer proof; the live site should not imply verified reviews.
