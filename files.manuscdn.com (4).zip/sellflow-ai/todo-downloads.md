# Download package checklist

- [ ] Generate the setup guide PDF from the latest v2 guide.
- [ ] Create the latest full-source zip.
- [ ] Upload the source zip, n8n workflow JSON, Google Sheet workbook, and setup guide PDF.
- [ ] Return the four direct download links.
