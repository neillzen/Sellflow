# SellFlow AI Sales + Onboarding Kit

## 10 cold DM scripts, each with three follow-ups

### 1. Slow replies
**DM:** Hi — quick one. How many WhatsApp enquiries does your store get after hours? We built a small AI salesperson for Harare boutiques that replies while you’re closed. Want to see a 30-second example?
**Follow-up 1:** The useful part is simple: price, size, delivery, then a clean handover when the shopper is ready.
**Follow-up 2:** It can use your own products, prices, EcoCash number and tone. No giant CRM.
**Follow-up 3:** Should I send the sample chat, or leave you to the racks?

### 2. Missed “available?” messages
**DM:** Your Instagram looks strong. The only leak may be the “is this available?” messages that arrive when you’re busy. SellFlow keeps those conversations warm automatically.
**Follow-up 1:** It asks for name, size and whether the customer wants the item held.
**Follow-up 2:** Your leads land in a simple Google Sheet for follow-through.
**Follow-up 3:** Worth a look for your next stock drop?

### 3. Follow-up gap
**DM:** Most stores don’t need more leads — they need the second message to happen. SellFlow follows up after 4 hours, then again the next day.
**Follow-up 1:** Short, polite, and based on the product the customer asked about.
**Follow-up 2:** Setup is a WhatsApp QR, your product list, and one sheet.
**Follow-up 3:** I can show you the exact flow in 2 minutes.

### 4. New stock
**DM:** New stock creates a rush of chats. What happens to the enquiries you can’t answer in that first hour? SellFlow gives each one a useful first reply.
**Follow-up 1:** It can mention sizes S–3XL, delivery in Harare and EcoCash — only what you provide.
**Follow-up 2:** No new phone for customers to learn.
**Follow-up 3:** Want the launch-day version of the chat?

### 5. Owner-led selling
**DM:** You should spend your time styling customers, not typing the same price reply 40 times. SellFlow handles the repetitive chat and leaves you the high-intent buyers.
**Follow-up 1:** It sounds warm, not like a call centre.
**Follow-up 2:** You can pause or change the flow whenever you like.
**Follow-up 3:** Shall I set up a free 14-day trial for [STORE_NAME]?

### 6. Local delivery
**DM:** If customers ask “do you deliver in Harare?” every day, Tari can answer that instantly and keep the conversation moving toward payment.
**Follow-up 1:** Add your delivery fee once; the assistant uses it consistently.
**Follow-up 2:** Add your EcoCash number once; the customer gets the right next step.
**Follow-up 3:** Reply “delivery” and I’ll send the sample.

### 7. Simple operator
**DM:** This is not another dashboard. It’s one helpful sales operator connected to your WhatsApp.
**Follow-up 1:** Customer asks. Tari answers. You see the lead.
**Follow-up 2:** Built for clothing stores in Harare, not generic enterprise teams.
**Follow-up 3:** Want to test it on 10 real enquiries?

### 8. Stock protection
**DM:** A shopper who says “I’ll think about it” may just need a timely nudge. SellFlow can remind them before the size disappears.
**Follow-up 1:** The message stays short and human.
**Follow-up 2:** You decide the products, prices and stock language.
**Follow-up 3:** Can I send the 20-hour follow-up example?

### 9. Revenue clarity
**DM:** Which products bring the most buying intent through WhatsApp? SellFlow logs every lead so you can spot the pattern.
**Follow-up 1:** Product, phone, message and status in one sheet.
**Follow-up 2:** Useful before your next buying decision.
**Follow-up 3:** I can walk you through the sheet in a quick voice note.

### 10. Direct offer
**DM:** We’re opening a few 14-day trials for Harare clothing stores. SellFlow replies to WhatsApp enquiries, follows up, and logs new leads. Interested?
**Follow-up 1:** Starter is $19/month after the trial.
**Follow-up 2:** No card required to begin.
**Follow-up 3:** Send your store name and I’ll show you the first reply.

## 20 FAQ answers for Tari

| Question | Answer |
|---|---|
| What is SellFlow AI? | It is a WhatsApp sales assistant for clothing stores. It answers common questions, follows up, and logs new leads. |
| What plans are available? | Starter is $19/month, Growth is $49/month, and Pro is $99/month. |
| Is there a free trial? | Yes, you can start with 14 days free. |
| What sizes can you support? | Add your available sizes; common options are S through 3XL. |
| Can you check live stock? | Tari only uses the stock information you provide, so keep your product sheet updated. |
| How much is delivery? | Your store sets the delivery fee. A common Harare range is $3–$5. |
| Do you deliver outside Harare? | Share the areas and fees you support; Tari should never guess. |
| Can I pay with EcoCash? | Yes. Add the correct EcoCash number and Tari can share it when the customer is ready. |
| Do you accept cash on delivery? | Only if your store does. Add your policy during onboarding. |
| What is your returns policy? | Add your exact policy. Tari should explain it clearly and avoid making exceptions. |
| When is new stock released? | Add your usual new-stock days, such as Fridays, to the store context. |
| Can I change prices? | Yes. Update the product list before asking Tari to quote the new price. |
| Does Tari send images? | The starter workflow focuses on text. You can add image sending later through Evolution API. |
| Is it a human? | Tari is an AI assistant. A store owner can step in whenever a customer needs personal help. |
| What if Tari does not know? | Tari should say it will confirm with the store rather than invent an answer. |
| How quickly does setup take? | A focused setup session is usually enough to connect the tools and add your store context. |
| Can I use my existing WhatsApp number? | Use the number you connect through the WhatsApp QR session and keep it available for the store. |
| Can I pause the follow-up? | Yes. Disable the workflow or update the lead status so follow-ups stop. |
| Where are leads stored? | The included workflow appends leads to a Google Sheet. |
| Is my data private? | Use only the accounts and keys you control, and avoid putting sensitive payment or identity data into chat prompts. |

## Store-owner onboarding form

1. What is your store name and Instagram handle?
2. What is the WhatsApp number to connect?
3. List every product you want Tari to sell, including price and colour.
4. Which sizes are available for each product (S, M, L, XL, 2XL, 3XL)?
5. What stock language should Tari use when stock is low or sold out?
6. What are your delivery areas and fee for each area?
7. What EcoCash number should Tari share for payment?
8. What are your opening hours and closed days?
9. What is your returns, exchange and hold policy?
10. How should Tari sound: warm, concise, playful, polished, or another tone?
